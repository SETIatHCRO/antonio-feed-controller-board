
extern char *LINESEP;
extern char *EOL;

void send_to_rimbox(char *msg);
