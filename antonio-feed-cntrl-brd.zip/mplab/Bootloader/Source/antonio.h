void antonio_bootloader_init();
void antonio_put_char(char chr);
BOOL antonio_poll();
char antonio_get_char();
