#include <stdint.h>

uint32_t adler(unsigned int length, unsigned char *data);